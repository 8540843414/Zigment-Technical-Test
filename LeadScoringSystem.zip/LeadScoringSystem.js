
const scores = {
    companySize: {
        "1-50 employees": 5,
        "51-200 employees": 10,
        "201-1000 employees": 20,
        "1000+ employees": 30
    },
    budget: {
        "Less than $10,000": 5,
        "$10,000 - $50,000": 10,
        "$50,001 - $100,000": 20,
        "More than $100,000": 30
    },
    industry: {
        "Technology": 20,
        "Finance": 15,
        "Healthcare": 10,
        "Retail": 10,
        "Other": 5
    },
    urgency: {
        "Immediate (within 1 month)": 20,
        "Short-term (1-3 months)": 15,
        "Medium-term (3-6 months)": 10,
        "Long-term (6+ months)": 5
    }
};

const totalScore =
    scores.companySize[inputData.companySize] +
    scores.budget[inputData.budget] +
    scores.industry[inputData.industry] +
    scores.urgency[inputData.urgency];

return { totalScore };
